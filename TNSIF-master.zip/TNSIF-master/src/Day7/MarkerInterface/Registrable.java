//Program to demonstrate Marker Interface
package Day7.MarkerInterface;

public interface Registrable {

}

//Program to demonstrate FunctionalInterface - Greet Interface
package Day7.InterfaceDEMO;

@FunctionalInterface
public interface GreetInterface {
	public String greet();
}

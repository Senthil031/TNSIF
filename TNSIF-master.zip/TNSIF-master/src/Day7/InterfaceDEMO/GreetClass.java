//Program to demonstrate FunctionalInterface - Child Class
package Day7.InterfaceDEMO;

public class GreetClass implements GreetInterface {

	@Override
	public String greet() {		
		return "Welcome to the world of Java";
	}

}

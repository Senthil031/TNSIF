//Program to demonstrate method overriding - Runtime Polymorphism
package Day6.Overriding;

//subclass
public class HDFC extends RBI {
	@Override
	public float getRateOfInterest() {
		return 6.8f;
	}

}
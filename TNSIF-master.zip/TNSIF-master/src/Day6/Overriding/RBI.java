//Program to demonstrate method overriding - Runtime Polymorphism
package Day6.Overriding;

//Superclass
public class RBI {
	public float getRateOfInterest() {
		return 6.7f;
	}

}

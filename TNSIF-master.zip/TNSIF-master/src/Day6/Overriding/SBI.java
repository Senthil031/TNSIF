//Program to demonstrate method overriding - Runtime Polymorphism
package Day6.Overriding;

//subclass
public class SBI extends RBI {
	@Override
	public float getRateOfInterest() {
		return 7.0f;
	}

	public SBI getObject() {
		return this;
	}
}

package Day1;

public class Foreach {
    public static void main(String[] args) {
        int[] a={10,20,30,40,50};
        for(int i:a){
            System.out.println(i);
        }
    }
    
}


package Day1;

public class foreachchar {
    public static void main(String[] args) {
        char[] n={'c','a','v'};
        for(char i:n){
            System.out.println(i);
        }
    }
    
}


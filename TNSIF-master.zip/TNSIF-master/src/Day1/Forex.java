package Day1;
import java.util.Scanner;
public class Forex {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int[] n={10,20,30,40,50};
        for(int i=0;i<5;i++){
            System.out.println(n[i]);

        }
        }

    }
    

